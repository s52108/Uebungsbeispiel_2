package org.campus02.oop;

public class Person {

	private String firstname;
	private String lastname;
	private char gender;
	private int age;
	private String country;
	private int salary;
	private String eyeColor;
	private int weight;
	private int size;
	
	public Person (String firstname, String lastname, char gender, int age, String country, int salary, String eyeColor, int weight, int size)
	{

	}
}
